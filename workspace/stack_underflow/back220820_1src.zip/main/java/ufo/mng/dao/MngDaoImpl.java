package ufo.mng.dao;

public class MngDaoImpl implements IMngDao {

}
