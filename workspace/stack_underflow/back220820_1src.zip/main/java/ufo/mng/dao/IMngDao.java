package ufo.mng.dao;

public interface IMngDao {

}
