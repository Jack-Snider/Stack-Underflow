package ufo.mng.service;

public class MngServiceImpl implements IMngService{

}
