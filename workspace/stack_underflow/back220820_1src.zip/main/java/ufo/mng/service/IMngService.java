package ufo.mng.service;

public interface IMngService {

}
