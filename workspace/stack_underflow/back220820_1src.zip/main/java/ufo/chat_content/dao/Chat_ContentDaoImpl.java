package ufo.chat_content.dao;

public class Chat_ContentDaoImpl implements IChat_ContentDao {

}
