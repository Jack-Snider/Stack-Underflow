package ufo.chat_content.dao;

public interface IChat_ContentDao {

}
