package ufo.chat_content.service;

public class Chat_ContentServiceImpl implements IChat_ContentService{

}
