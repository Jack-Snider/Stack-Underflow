package ufo.chat_content.service;

public interface IChat_ContentService {

}
