package ufo.vo;

public class Chat_ContentVO {

	private String chat_cont_wrt; // 작성자
	private String chat_cont_cont; // 내용
	private String chat_cont_time; // 작성일 ( DATE타입 )
	private int chat_room_num; // 방번호
	private String chat_cont_srlnum; // 시리얼번호
	
	public String getChat_cont_wrt() {
		return chat_cont_wrt;
	}
	public void setChat_cont_wrt(String chat_cont_wrt) {
		this.chat_cont_wrt = chat_cont_wrt;
	}
	public String getChat_cont_cont() {
		return chat_cont_cont;
	}
	public void setChat_cont_cont(String chat_cont_cont) {
		this.chat_cont_cont = chat_cont_cont;
	}
	public String getChat_cont_time() {
		return chat_cont_time;
	}
	public void setChat_cont_time(String chat_cont_time) {
		this.chat_cont_time = chat_cont_time;
	}
	public int getChat_room_num() {
		return chat_room_num;
	}
	public void setChat_room_num(int chat_room_num) {
		this.chat_room_num = chat_room_num;
	}
	public String getChat_cont_srlnum() {
		return chat_cont_srlnum;
	}
	public void setChat_cont_srlnum(String chat_cont_srlnum) {
		this.chat_cont_srlnum = chat_cont_srlnum;
	}
	
	
	
	
	
	
}
