package ufo.vo;

public class Manage_TypeVO {

	private String mng_type_cd; // 관리유형코드 ( 퇴출인지, 경고인지 등등... )
	private String mng_type_nm; // 관리유형이름
	
	
	public String getMng_type_cd() {
		return mng_type_cd;
	}
	public void setMng_type_cd(String mng_type_cd) {
		this.mng_type_cd = mng_type_cd;
	}
	public String getMng_type_nm() {
		return mng_type_nm;
	}
	public void setMng_type_nm(String mng_type_nm) {
		this.mng_type_nm = mng_type_nm;
	}
	
	 
	
}
