package ufo.chat.service;

public interface IChatService {

}
