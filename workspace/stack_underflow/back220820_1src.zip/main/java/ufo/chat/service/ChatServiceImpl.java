package ufo.chat.service;

public class ChatServiceImpl implements IChatService {

}
