package ufo.chat.dao;

public interface IChatDao {

}
