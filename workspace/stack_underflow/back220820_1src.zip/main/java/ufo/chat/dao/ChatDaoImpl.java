package ufo.chat.dao;

public class ChatDaoImpl implements IChatDao{

}
