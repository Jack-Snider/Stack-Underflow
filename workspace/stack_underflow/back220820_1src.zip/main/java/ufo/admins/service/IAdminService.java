package ufo.admins.service;

public interface IAdminService {

}
