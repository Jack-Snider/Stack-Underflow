package ufo.admins.service;

public class AdminServiceDao {

}
