package ufo.admins.dao;

public interface IAdminDao {

}
