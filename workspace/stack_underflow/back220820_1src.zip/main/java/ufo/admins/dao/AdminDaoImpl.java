package ufo.admins.dao;

public class AdminDaoImpl implements IAdminDao {

}
