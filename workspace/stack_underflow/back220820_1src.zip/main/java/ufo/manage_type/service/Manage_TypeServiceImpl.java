package ufo.manage_type.service;

public class Manage_TypeServiceImpl {

}
