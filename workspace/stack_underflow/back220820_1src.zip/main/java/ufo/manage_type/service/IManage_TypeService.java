package ufo.manage_type.service;

public interface IManage_TypeService {

}
