package ufo.manage_type.dao;

public class Manage_TypeDaoImpl implements IManage_TypeDao{

}
