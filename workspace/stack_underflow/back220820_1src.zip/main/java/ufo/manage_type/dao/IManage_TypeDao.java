package ufo.manage_type.dao;

public interface IManage_TypeDao {

}
